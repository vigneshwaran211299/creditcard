#-----Section 01-------------------------------------------

# set working directory
setwd(dirname(file.choose()))
getwd()

# read in data from csv file
London.dis <- read.csv("10_London_districts.csv", stringsAsFactors = FALSE)
head(London.dis)
str(London.dis)

#dev.list()
#dev.off()
#options(device)
#options(device = "RStudioGD")
#options(device = "windows")

attach(London.dis)

#-----Section 02-------------------------------------------

cor.test(Deprivation, Life_Male, method = "spearman")

plot(Deprivation, Life_Male, main = "Scatterplot",
     xlab = "Deprivation", ylab = "Male Life Expectancy")

# Test dependent variable for normality
# graphically
qqnorm(Life_Male, xlab = "Theoretical Quantiles: Life_Male" )
qqline(Life_Male, col = 2) ## red color
# K-S test
ks.test(Life_Male, "pnorm", mean(Life_Male), sd(Life_Male))
# or... Shapiro-Wilk's test
shapiro.test(Life_Male)

# Linear Regression
model1 <- lm(Life_Male ~ Deprivation)

# add regression line to scatter plot
plot(Deprivation, Life_Male, main = "Scatterplot",
     xlab = "Deprivation", ylab = "Male Life Expectancy")
abline(model1, col = "red")

summary(model1)

hist(model1$residuals)
rug(model1$residuals)
# consider normality of residuals
plot(model1$residuals ~ model1$fitted.values, xlab = "fitted values", ylab = "residuals")
ks.test(model1$residuals, "pnorm", mean(model1$residuals), sd(model1$residuals))

#-----Section 03-------------------------------------------

# Factors Analysis (from session9)

# select variables by excluding those not required
myvars <- names(London.dis) %in% c("Code", "Name", "Age0_19","Age20_64",
                                   "Age65plus", "Deprivation")
London.dis2 <- London.dis[!myvars]
# or...
#London.dis2 <- names(London.dis[c(-1,-2,-3,-4,-5,-6)])
str(London.dis2)
rm(myvars)

# or...select variables that are required
#myvars <- names(London.dis[c(7,8,9,10,11,12,13,14,15,16,17,18)])
# or...
#myvars <- names(London.dis[c(7:18)])
#London.dis2 <- London.dis[myvars]
#str(London.dis2)
#rm(myvars)

# Correlation matrix for all variables
cor.matrix <- cor(London.dis2, use = "pairwise.complete.obs", method = "spearman")
cor.df <- as.data.frame(round(cor.matrix, 2))
View(cor.df)
library(corrplot)
corrplot(cor.matrix, type = "upper", tl.col = "black", tl.srt = 45)

# select variables by excluding dependent variables and others not required
myvars <- names(London.dis) %in% c("Code", "Name", "Age0_19","Age20_64",
                                   "Age65plus", "Deprivation", "Life_Male", "Life_Female")
London.dis3 <- London.dis[!myvars]
str(London.dis3)
rm(myvars)

library(nFactors)
library(psych)

# Kaiser-Meyer-Olkin statistics: if overall MSA > 0.6, proceed to factor analysis
KMO(cor(London.dis3))

# get eigenvalues
ev <- eigen(cor(London.dis3))
ev$values
# plot a scree plot of eigenvalues
plot(ev$values, type="b", col= "blue", xlab="variables")

# calculate cumulative proportion of eigenvalue and plot
ev.sum <- 0
for(i in 1:length(ev$value)){
  ev.sum <- ev.sum+ev$value[i]
}
ev.list1 <- 1:length(ev$value)
for(i in 1:length(ev$value)){
  ev.list1[i] <- ev$value[i]/ev.sum
}
ev.list2 <- 1:length(ev$value)
ev.list2[1] <- ev.list1[1]
for(i in 2:length(ev$value)){
  ev.list2[i] <- ev.list2[i-1]+ev.list1[i]
}
plot (ev.list2, type = "b", col = "red", xlab = "number of components", ylab = "cumulative proportion")

# Varimax Rotated Principal Components
# retaining 'nFactors' components
library(GPArotation)

fit <- principal(London.dis3, nfactors = 4, rotate = "varimax")
fit

# weed out further variables after first factor analysis
myvars <- names(London.dis3) %in% c("Binge_Drink", "Benefits")
London.dis3 <- London.dis3[!myvars]
str(London.dis3)
rm(myvars)

# get eigenvalues
ev <- eigen(cor(London.dis3))
ev$values
# plot a scree plot of eigenvalues
plot(ev$values, type = "b", col = "blue", xlab = "variables")

fit <- principal(London.dis3, nfactors = 4, rotate = "varimax")
fit

# create four variables to represent the rorated components
fit$scores
fit.data <- data.frame(fit$scores)

# check new variables are uncorrelated
cor.matrix2 <-cor(fit.data, method = "spearman")
cor.df2 <- as.data.frame(cor.matrix2)
round(cor.df2, 2)

#-----Section 04-------------------------------------------

# Multiple Regression

# model with all variables
model2 <- lm(Life_Male ~ Dom_Build  + NonDom_Build + Dom_Gardens + Greenspace
             + Smoking + Binge_Drink + Obese + Episodes + Benefits + Crime)
summary(model2)
# calculate variance inflation factor
library(car)
vif(model2)
sqrt(vif(model2)) > 2  # if > 2 vif too high

# model with four variables representing components from factor analysis
cor3 <- cor(London.dis2[, c(5,4,12,7,10)], method = "spearman")
round(cor3, 2)
corrplot(cor3, type = "upper", tl.col = "black", tl.srt = 45)

model3 <- lm(Life_Male ~ Greenspace + Crime + Smoking + Episodes)
summary(model3)
sqrt(vif(model3)) > 2

#calculate partial correlation
library(ppcor)
pcor.test(Life_Male, Crime, Greenspace)
pcor.test(Life_Male, Greenspace, Crime)

model3a <- lm(Life_Male ~ Greenspace + Smoking + Episodes)
summary(model3a)
sqrt(vif(model3a)) > 2

# relative importance of variables
library(relaimpo)
calc.relimp(model3a, type = c("lmg"), rela = TRUE)

# use a stepwise approach to search for a best model
library(RcmdrMisc)

# add other correlating variables not in components
cor3b <- cor(London.dis2[, c(5,4,12,7,10,8,11)], method = "spearman")
corrplot(cor3b, type = "upper", tl.col = "black", tl.srt = 45)

model3b <- lm (Life_Male ~ Greenspace + Crime + Smoking + Episodes +
                 Binge_Drink + Benefits)
summary(model3b)
sqrt(vif(model3b)) > 2
calc.relimp(model3b, type = c("lmg"), rela = TRUE)

# forward stepwise selection
model4 <- stepwise(model3b, direction = "forward")
summary(model4)
hist(model4$residuals)
rug(model4$residuals)
plot(model4$residuals ~ model4$fitted.values, xlab = "fitted values", ylab = "residuals")
ks.test(model4$residuals, "pnorm", mean(model4$residuals), sd(model4$residuals))
sqrt(vif(model4)) > 2
calc.relimp(model4, type = c("lmg"), rela = TRUE)

# test whether model2 and model4 are significantly different using F test
anova(model2, model4, test = "F")

# use a stepwise approach to search for a best model
model5 <- stepwise(model2, direction = "forward")
summary(model5)
hist(model5$residuals)
rug(model5$residuals)
plot(model5$residuals ~ model5$fitted.values, xlab = "fitted values", ylab = "residuals")
ks.test(model5$residuals, "pnorm", mean(model5$residuals), sd(model5$residuals))
sqrt(vif(model5)) > 2
calc.relimp(model5, type = c("lmg"), rela = TRUE)

# test whether model2 and model5 are significantky different using F test
anova(model2, model5, test = "F")

# model from new variables derived from factor analysis
model6 <- lm (Life_Male ~ fit.data$RC1 + fit.data$RC2 + fit.data$RC3 + fit.data$RC4)
summary (model6)

# use a stepwise approach to search for a best model
model7 <- stepwise(model6, direction = "forward")
summary (model7)
hist(model7$residuals)
rug(model7$residuals)
plot(model7$residuals ~ model7$fitted.values, xlab = "fitted values", ylab = "residuals")
ks.test(model7$residuals, "pnorm", mean(model7$residuals), sd(model7$residuals))
sqrt(vif(model7)) > 2
calc.relimp(model7, type = c("lmg"), rela = TRUE)

# test whether model7 and model6 are significantly different using F test
anova(model6, model7, test = "F")


#-----Section 05-------------------------------------------

detach(London.dis)

#-----Section 06-------------------------------------------

# read in data from csv file
low.bwt <- read.csv("10_low_bwt.csv", stringsAsFactors = FALSE)
head(low.bwt)
str(low.bwt)

# check for missing data
apply(low.bwt, MARGIN = 2, FUN = function(x) sum(is.na(x)))
library(Amelia)
missmap(low.bwt, col = c("black", "grey"), legend = FALSE)
low.bwt <- na.omit(low.bwt) # remove any missing data

#change categorical variable to factors
low.bwt$low_bwt <- factor(low.bwt$low_bwt)
low.bwt$birth <- factor(low.bwt$birth)
low.bwt$smoke <- factor(low.bwt$smoke)
low.bwt$ethnic <- factor(low.bwt$ethnic)
str(low.bwt)

# correlations between variables
library(polycor)

low.bwt.cor <- hetcor(low.bwt[-1])
low.bwt.cor$type
round(low.bwt.cor$correlations, 2)

# first round use all variables
mylogit1 <- glm(low_bwt ~ birth + smoke + ethnic + m_age + mwt,
                data = low.bwt, family = "binomial")
summary(mylogit1)
sqrt(vif(mylogit1)) > 2

# second round excluding not significant variables
mylogit2 <- glm(low_bwt ~ smoke + ethnic + mwt,
                data = low.bwt, family = "binomial")
summary(mylogit2)
sqrt(vif(mylogit2)) > 2

#-----Section 07-------------------------------------------

# calculate Odds Ratio - Exp(b)
exp(coef(mylogit2))
# calculate the 95% confidence intervals (2 tail)
exp(cbind(OR = coef(mylogit2), confint(mylogit2)))

#-----Section 08-------------------------------------------

# third round using stepwise on first round model
mylogit3 <- stepwise(mylogit1, direction="forward")
summary(mylogit3)

# calculate Odds Ratio - Exp(b)
exp(coef(mylogit3))
# calculate the 95% confidence intervals (2 tail)
exp(cbind(OR = coef(mylogit3), confint(mylogit3)))

# variable relative importance for glm() models - absolute value of t
library(caret)
varImp(mylogit3)

# McFadden's R squared
nullmod <- glm(low_bwt ~ 1, data = low.bwt, family="binomial")
mcf1 <- 1 - logLik(mylogit3) / logLik(nullmod)
mcf1

# test improvement using Davidson-MacKinnon j-test for comparing non-nested models
library(lmtest)
jtest(mylogit1, mylogit2)
# or if nested models
# anova(mylogit1, mylogit2)

#-----Section 09-------------------------------------------

# Poisson Regression

London.mur <- read.csv("10_London_poisson.csv", stringsAsFactors = FALSE)
str(London.mur)
head(London.mur)

# select variables by excluding those not required
myvars <- names(London.mur) %in% c("Code", "Name")
London.mur2 <- London.mur[!myvars]
rm(myvars)

# correlations between variables
library(corrgram)
corrgram(London.mur2, order = FALSE, cor.method = "spearman", lower.panel = panel.cor,
         upper.panel = panel.pie, text.panel = panel.txt, main = "London variables")

#-----Section 10-------------------------------------------

# if mean ~= var, then OK otherwise over-dispersed
mean(London.mur2$Murder)
var(London.mur2$Murder)

# poisson regression using glm() for mean = var
mypoiss1 <- glm(Murder ~ Benefits + Episodes + Binge_Drink + Smoking
                + Greenspace+ NonDom_Build + Dom_Build + Age0_19,
                data = London.mur2, family = "poisson")
summary (mypoiss1)

# poisson regression using glm() for over-dispersed
mypoiss2 <- glm(Murder ~ Benefits + Episodes + Binge_Drink + Smoking
                + Greenspace+ NonDom_Build + Dom_Build + Age0_19,
                data = London.mur2, family = "quasipoisson")
summary (mypoiss2)

# refine
mypoiss3 <- glm(Murder ~ Benefits + Greenspace + NonDom_Build,
                data = London.mur2, family = "poisson")
summary (mypoiss3)

# calculate Odds Ratio - Exp(b)
exp(coef(mypoiss3))
# calculate the 95% confidence intervals (2 tail)
exp(cbind(OR = coef(mypoiss3), confint(mypoiss3)))

# variable relative importance for glm() models - absolute value of t
library(caret)
varImp(mypoiss3)

histogram(mypoiss3$residuals, col = "Grey")
plot(London.mur2$Murder, mypoiss3$fitted.values)

# McFadden's R squared # only for model = "poisson"]
nullmod <- glm(Murder ~ 1, data = London.mur2, family = "poisson")
mcf2 <- 1 - logLik(mypoiss3) / logLik(nullmod)
mcf2

#-----Section 11-------------------------------------------

# remove all variables from the environment
rm(list=ls())

